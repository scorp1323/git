<?php

/*
 * PHP Start | Теория
 * Урок 3: Типы данных
 * Задача 1 
 */

// Присваиваем переменным значения
$a = 152;
$b = '152';
$c = 'London';
$d = array(152);
$e = 15.2;
$f = false;
$g = true;

// Выводим информацию о типах
echo 'Тип переменной $a - ' . gettype($a) . '<br>';
echo 'Тип переменной $b - ' . gettype($b) . '<br>';
echo 'Тип переменной $c - ' . gettype($c) . '<br>';
echo 'Тип переменной $d - ' . gettype($d) . '<br>';
echo 'Тип переменной $e - ' . gettype($e) . '<br>';
echo 'Тип переменной $f - ' . gettype($f) . '<br>';
echo 'Тип переменной $g - ' . gettype($g) . '<br>';
