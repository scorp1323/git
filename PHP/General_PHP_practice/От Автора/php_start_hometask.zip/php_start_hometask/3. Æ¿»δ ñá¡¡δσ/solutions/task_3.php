<?php

/*
 * PHP Start | Теория
 * Урок 3: Типы данных
 * Задача 3
 */

// Исходные данные
$string1 = " и господа";
$string2 = " дамы";
$string3 = "Доброе утро,";

// Формирование строки
$result = $string3;
$result .= $string2;
$result .= $string1;

// Вывод результата
echo $result;
